import React from 'react';
import PetOwnerNotificationsScreen from '../src/screens/app/PetOwnerNotificationsScreen';

export default function PetOwnerNotifications() {
  return <PetOwnerNotificationsScreen />;
} 