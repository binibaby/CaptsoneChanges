import React from 'react';
import FindSitterMapScreen from '../src/screens/app/FindSitterMapScreen';

export default function FindSitterMap() {
  return <FindSitterMapScreen />;
} 