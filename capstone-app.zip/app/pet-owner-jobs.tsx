import React from 'react';
import PetOwnerJobsScreen from '../src/screens/app/PetOwnerJobsScreen';

export default function PetOwnerJobs() {
  return <PetOwnerJobsScreen />;
} 