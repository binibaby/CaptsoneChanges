import React from 'react';
import PetSitterDashboard from '../src/screens/app/PetSitterDashboard';

export default function PetSitterDashboardRoute() {
  return <PetSitterDashboard />;
} 