import React from 'react';
import PetSitterScheduleScreen from '../src/screens/app/PetSitterScheduleScreen';

export default function PetSitterSchedule() {
  return <PetSitterScheduleScreen />;
} 