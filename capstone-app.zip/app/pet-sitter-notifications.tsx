import React from 'react';
import PetSitterNotificationsScreen from '../src/screens/app/PetSitterNotificationsScreen';

export default function PetSitterNotifications() {
  return <PetSitterNotificationsScreen />;
} 