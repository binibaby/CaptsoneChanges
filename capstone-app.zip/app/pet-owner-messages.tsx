import React from 'react';
import PetOwnerMessagesScreen from '../src/screens/app/PetOwnerMessagesScreen';

export default function PetOwnerMessages() {
  return <PetOwnerMessagesScreen />;
} 