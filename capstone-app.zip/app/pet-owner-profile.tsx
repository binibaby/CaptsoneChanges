import React from 'react';
import PetOwnerProfileScreen from '../src/screens/app/PetOwnerProfileScreen';

export default function PetOwnerProfile() {
  return <PetOwnerProfileScreen />;
} 