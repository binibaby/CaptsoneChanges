import React from 'react';
import PetSitterRequestsScreen from '../src/screens/app/PetSitterRequestsScreen';

export default function PetSitterRequests() {
  return <PetSitterRequestsScreen />;
} 