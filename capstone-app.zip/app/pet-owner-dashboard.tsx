import React from 'react';
import PetOwnerDashboard from '../src/screens/app/PetOwnerDashboard';

export default function PetOwnerDashboardRoute() {
  return <PetOwnerDashboard />;
} 