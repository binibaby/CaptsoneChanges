import React from 'react';
import PetSitterProfileScreen from '../src/screens/app/PetSitterProfileScreen';

export default function PetSitterProfile() {
  return <PetSitterProfileScreen />;
} 