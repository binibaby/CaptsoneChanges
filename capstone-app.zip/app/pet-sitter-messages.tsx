import React from 'react';
import PetSitterMessagesScreen from '../src/screens/app/PetSitterMessagesScreen';

export default function PetSitterMessages() {
  return <PetSitterMessagesScreen />;
} 