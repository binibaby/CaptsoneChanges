import React from 'react';
import PetSitterAvailabilityScreen from '../src/screens/app/PetSitterAvailabilityScreen';

export default function PetSitterAvailability() {
  return <PetSitterAvailabilityScreen />;
} 